% We are doing the simulation of the zig zag EOBD Start by loading in the 
% phase maps from Comsol. These are slices through half a triangle.
%phase_m0 = load('zig_phase_map_0.csv');
phase_m1 = load('zig_phase_map_1.csv');
phase_m2 = load('zig_phase_map_2.csv');
phase_m3 = load('zig_phase_map_3.csv');
phase_m4 = load('zig_phase_map_4.csv');
phase_m5 = load('zig_phase_map_5.csv');
phase_m6 = load('zig_phase_map_6.csv');
phase_m7 = load('zig_phase_map_7.csv');
phase_m8 = load('zig_phase_map_8.csv');

%the data for phase map 0 is odd, so we use the last map rotated with the
%sign inverted to replace it.
phase_m0 = flip(phase_m8, 2).*-1;

% place all of the phase maps into a vector so that we can iterate over
% them
phase_vec = {phase_m0, phase_m1, phase_m2, phase_m3, phase_m4, phase_m5, phase_m6, phase_m7, phase_m8};

% define wavelength and grid
lambda = 1064e-9;
X = linspace(-0.002, 0.002, 201);
Y = X;
[XX, YY] = meshgrid(X, Y);

%finally define the z space
zs = linspace(-0.02, 0.02, 81);

% in order to traverse the phase maps such that we recreate the electric
% field of the zig zagging electrode we define an interator and a logic
% variable.

m = 1;
direction = 0;

for n=1:81
    % set new q parameter
    gp=FT_init_gauss_param(lambda,1.774,'w0',250e-6,'z',zs(n));
    gc = FT_init_gauss_coefficients('HG', 6);
    % if first one, generate initial field
    if n==1
        beam=FT_HG_field(gp,0,0,X,Y,[0,0,0]);
    % otherwise, build field from previous set of mode coefficients and new
    % q parameter
    else
        beam=FT_mode_coefficients_to_field(defgc,gp,X,Y,[0,0,0],0);
    end
    
    % if we are at the first index then our direction flips
    if m == 1
        direction = 0;
    end
    
    % similarly if we are at the last we flip.
    if m == 9
        direction = 1;
    end
    
    % apply phasemap of this slice
    defbeam=beam.*exp(1i*cell2mat(phase_vec(m)));
    % calculate new mode coefficients
    defgc=FT_mode_content(gc,gp,defbeam,X,Y,[0,0,0]);
    % plot the phase front of this slice
    plot(X,angle(defbeam(50,:))*180/pi)
    hold on
    
    % if we are going up a triangle in the electrode then we increment the
    % index
    if direction == 0
        m = m + 1;
    % else, if we are going down, we decrement the index
    else
        m = m - 1;
    end
end

FT_print_gauss_coefficients(defgc, 0, 1)